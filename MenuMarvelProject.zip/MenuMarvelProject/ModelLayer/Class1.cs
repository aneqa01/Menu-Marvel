﻿namespace ModelLayer
{
    public class Class1
    {

    }
}