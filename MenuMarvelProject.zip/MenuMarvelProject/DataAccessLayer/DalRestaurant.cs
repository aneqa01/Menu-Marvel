﻿using ModelLayer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DataAccessLayer
{
    public class dalRestaurant
    {
        public static List<ModelRestaurant> GetRestaurantsinfo()
        {
            SqlConnection con = DBHelper.GetConnection();
            SqlCommand cmd = new SqlCommand("select * from Restaurant", con);
            con.Open();
            SqlDataReader sqlDataReaderreader = cmd.ExecuteReader();
            List<ModelRestaurant> listRestaurant = new List<ModelRestaurant>();
            while (sqlDataReaderreader.Read())
            {
                ModelRestaurant rest1 = new ModelRestaurant();
                rest1.id = Convert.ToInt32(sqlDataReaderreader["id"]);
                rest1.food = sqlDataReaderreader["food"].ToString();
                rest1.name = sqlDataReaderreader["name"].ToString();
                listRestaurant.Add(rest1);

            }
            con.Close();
            return listRestaurant;
        }

        public static void SaveRestaurantsInfo(ModelRestaurant modelRestaurant)
        {
            SqlConnection con = DBHelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("SP_saveProducts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@id", modelRestaurant.id);
            cmd.Parameters.AddWithValue("@name", modelRestaurant.name);
            cmd.Parameters.AddWithValue("@food", modelRestaurant.food);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void DeleteRestaurantsInfo(int id)
        {
            SqlConnection con = DBHelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("SP_DeleteRestaurant", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void UpdateRestaurantInfo(ModelRestaurant modelRestaurant)
        {
            SqlConnection con = DBHelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("SP_UpdateRestaurant", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", modelRestaurant.id);
            cmd.Parameters.AddWithValue("@name", modelRestaurant.name);
            cmd.Parameters.AddWithValue("@food", modelRestaurant.food);
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}
