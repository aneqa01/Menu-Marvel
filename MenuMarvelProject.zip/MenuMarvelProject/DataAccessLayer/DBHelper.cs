﻿using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class DBHelper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-REC0NDU\\SAMEERSQL;Initial Catalog=MenuMarvel;Integrated Security=True");
            return con;
        }
    }
}